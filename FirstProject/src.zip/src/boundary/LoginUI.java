package boundary;

import entity.Login;
import control.LoginController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LoginUI extends JFrame {
    private JTextField emailField = new JTextField(15);
    private JPasswordField passwordField = new JPasswordField(15);
    private JButton btnLogin = new JButton("Login");
    private JComboBox<String> cbRole = new JComboBox<>(new String[]{"", "Admin", "Agent", "Buyer","Seller"});
    private JLabel resetPasswordLabel = new JLabel("<html><u>Reset Password</u></html>");

    public LoginUI() {
        super("Login");
        layoutComponents();
        setupLoginButton();
        setupResetPassword();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void layoutComponents() {
        setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(10, 10, 10, 10);

        addComponent(new JLabel("Email:"), 0, 0);
        addComponent(emailField, 1, 0);
        addComponent(new JLabel("Password:"), 0, 1);
        addComponent(passwordField, 1, 1);
        addComponent(new JLabel("Role:"), 0, 2);
        addComponent(cbRole, 1, 2);

        constraints.gridx = 1;
        constraints.gridy = 3;
        constraints.anchor = GridBagConstraints.CENTER;
        add(btnLogin, constraints);
        
        constraints.gridy = 4; 
        constraints.insets = new Insets(20, 10, 10, 10); 
        add(resetPasswordLabel, constraints);
    }

    private void setupLoginButton() {
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());
                String chosenType = (String) cbRole.getSelectedItem();

                Login user = new Login(email, password, chosenType);
                LoginController loginController = new LoginController(user);
                String userId = loginController.authenticate();
                if (userId != null) {
                    JOptionPane.showMessageDialog(LoginUI.this, "Authenticated with user_id: " + userId);
                } else {
                    JOptionPane.showMessageDialog(LoginUI.this, "Authentication failed, please check your email and password");
                }
            }
        });
    }
    
    private void setupResetPassword() {
        resetPasswordLabel.setForeground(Color.BLUE); 
        resetPasswordLabel.setCursor(new Cursor(Cursor.HAND_CURSOR)); 
        resetPasswordLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                JPanel resetPanel = new JPanel(new GridLayout(0, 1));
                JLabel labelEmail = new JLabel("Email:");
                JTextField textEmail = new JTextField();
                JLabel labelOldPassword = new JLabel("Old Password:");
                JPasswordField textOldPassword = new JPasswordField();
                JLabel labelNewPassword = new JLabel("New Password:");
                JPasswordField textNewPassword = new JPasswordField();
                
                resetPanel.add(labelEmail);
                resetPanel.add(textEmail);
                resetPanel.add(labelOldPassword);
                resetPanel.add(textOldPassword);
                resetPanel.add(labelNewPassword);
                resetPanel.add(textNewPassword);
                
                int result = JOptionPane.showConfirmDialog(LoginUI.this, resetPanel, 
                    "Reset Password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                
                if (result == JOptionPane.OK_OPTION) {
                    String email = textEmail.getText();
                    String oldPassword = new String(textOldPassword.getPassword());
                    String newPassword = new String(textNewPassword.getPassword());
                    
                    Login user = new Login(email, oldPassword, newPassword,"yes");
                    LoginController loginController = new LoginController(user);
                    String resetStatus = loginController.resetPassword();
                    JOptionPane.showMessageDialog(LoginUI.this, resetStatus);
                }
            }
        });
    }

    private void addComponent(Component component, int x, int y) {
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = x;
        constraints.gridy = y;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(10, 10, 10, 10);
        add(component, constraints);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginUI());
    }
}
