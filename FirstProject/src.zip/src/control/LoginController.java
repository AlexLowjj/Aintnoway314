package control;

import entity.Login;

public class LoginController {
    private Login userLoginEnt;

    public LoginController(Login userLoginEnt) {
        this.userLoginEnt = userLoginEnt;
    }

    public String authenticate() {
        return userLoginEnt.authenticate();
    }
    
    public String resetPassword() {
        boolean result = userLoginEnt.resetPassword();
        if (result) {return "Password reset successful";} 
        else {return "Password reset failed, please check your email or password";}
    }
    

}
