package entity;

import csit314.ConnectDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login {
    private String email;
    private String password;
    private String chosenType;
	private String newPassword;
	private String status;

    public Login(String email, String password, String chosenType) {
        this.email = email;
        this.password = password;
        this.chosenType = chosenType;
    }
    
    public Login(String email, String password, String newPassword, String status) {
        this.email = email;
        this.password = password;
        this.newPassword = newPassword;
        this.status = status;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public boolean resetPassword() {
        Connection conn = ConnectDB.connect();
        if (conn == null) {
            System.out.println("Unable to connect to the database.");
            return false;
        }

        String selectSql = "SELECT user_id FROM temp WHERE email = ? AND password = ?";
        try (PreparedStatement selectPstmt = conn.prepareStatement(selectSql)) {
            selectPstmt.setString(1, this.email);
            selectPstmt.setString(2, this.password);

            try (ResultSet rs = selectPstmt.executeQuery()) {
                if (rs.next()) {
                    String updateSql = "UPDATE temp SET password = ? WHERE email = ?";
                    try (PreparedStatement updatePstmt = conn.prepareStatement(updateSql)) {
                        updatePstmt.setString(1, this.newPassword);
                        updatePstmt.setString(2, this.email);
                        int affectedRows = updatePstmt.executeUpdate();
                        return affectedRows > 0;
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error closing the database connection: " + e.getMessage());
            }
        }
        return false;
    }

        
        
    

    public String authenticate() {
        Connection conn = ConnectDB.connect();
        if (conn == null) {
            System.out.println("Unable to connect to the database.");
            return null;
        }
        
        String typeID = "";
        String tableName = "";
        
        if( chosenType == "Agent") {
        	typeID = "AgentID";tableName="Agent"; 	
        } else if ( chosenType == "Buyer") {
        	typeID = "buyerID";tableName="Buyer"; 	
        } else if ( chosenType == "Seller") {
        	typeID = "sellerID";tableName="Seller"; 	
        } else if ( chosenType == "Admin") {
        	typeID = "adminID";tableName="Admin"; 	
        } else {
        	//
        }

        String sql = "SELECT user_id FROM \"public\".\"temp\" WHERE email = ? AND password = ?";
//        String sql = "SELECT " + tableName + "."+typeID+" FROM \"public\".\"" + tableName + "\" JOIN \"public\".\"Users\" ON " + tableName + "."+typeID+" = Users.UserID WHERE Users.email = ? AND Users.password = ?;";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, this.email);
            pstmt.setString(2, this.password);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String userId = rs.getString("user_id"); // Assuming 'user_id' is the column name in your database
                    System.out.println("Authenticated with user_id: " + userId); // Print user_id to the console
                    return userId;
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error closing the database connection: " + e.getMessage());
            }
        }
        return null; 
    }

}
