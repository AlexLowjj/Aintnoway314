/**
 * 
 */
/**
 * 
 */


module FirstProject {
	requires java.sql;
	requires java.desktop;

}